package PiedraPapelTijera;

public class Final {

	public static void main(String[] args) {
		Grafica.iniciarGame();
	}

}
